--
-- Database: `ci_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `logins`
--

CREATE TABLE `logins` (
  `login_id` int(10) UNSIGNED NOT NULL,
  `personal_info_id` int(11) NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `remember_token` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `logins`
--

INSERT INTO `logins` (`login_id`, `personal_info_id`, `username`, `password`, `key`, `status`, `remember_token`, `role`, `created_at`, `updated_at`) VALUES
(1, 1, 'admin', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'Ebzo4xDZn5cTa3Adu8gJyfPimtBwGU1x', 1, '7110eda4d09e062aa5e4a390b0a572ac0d2c022', 'admin', NULL, NULL),
(2, 2, 'jcruz', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'Ebzo4xDZn5cTa3Adu8gJyfPimtBwGU2', 1, 't2FhqQVy6F2qLivTm3XrpcCZg7fDL26jyqGZAGcU', 'user', NULL, NULL),
(3, 6, 'jcr', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'Ebzo4xDZn5cTa3Adu8gJyfPimtBwGU1s', 1, 'Ebzo4xDZn5cTa3Adu8gJyfPimtBwGU1s', 'user', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `settings_id` int(10) UNSIGNED NOT NULL,
  `settings_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`settings_id`, `settings_name`, `value`, `status`) VALUES
(1, 'favicon', 'favicon.ico', '1'),
(2, 'site_name', 'Base Portal', '1'),
(3, 'site_logo', 'ceciro.png', '1'),
(4, 'email_sender', 'no-reply@domain.com', '1'),
(5, 'date_format', 'm/d/Y', '1'),
(6, 'company_name', 'Company', '1'),
(7, 'email_cc', 'john@primeview.com,jcruz@optimizex.com', '1'),
(8, 'email_bcc', 'john@primeview.com,jcruz@optimizex.com', '1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `personal_info_id` int(10) UNSIGNED NOT NULL,
  `fname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `display_pic` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `civil_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`personal_info_id`, `fname`, `mname`, `lname`, `address`, `email_address`, `contact_number`, `company`, `birthday`, `display_pic`, `gender`, `civil_status`, `created_at`) VALUES
(1, 'John Perri', 'Doe', 'Cruz', 'Alabang - Zapote Road, Ayala Alabang', 'john@primeview.com', '9357948608', 'OptimizeX', '2017-12-30', 'ox-shirt-white.jpg', 'Male', 'single', '2017-06-20 16:53:55'),
(2, 'John Perri', 'A.', 'Cruz', 'Muntinlupa City', 'jcruz@optimizex.com', '09089359789', 'OptimizeX', '2017-10-16', 'screenshot.png', 'Male', 'single', '2017-10-16 14:54:19'),
(6, 'John', '', 'Primeview', 'Muntinlupa City', 'johnperricruz@gmail.com', '09089359789', 'Optimizex', '2017-12-13', 'ox-shirt-white.jpg', 'Male', 'single', '2017-12-13 16:41:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `logins`
--
ALTER TABLE `logins`
  ADD PRIMARY KEY (`login_id`),
  ADD UNIQUE KEY `logins_username_unique` (`username`),
  ADD UNIQUE KEY `key` (`key`),
  ADD UNIQUE KEY `remember_token` (`remember_token`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`settings_id`),
  ADD UNIQUE KEY `settings_settings_name_unique` (`settings_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`personal_info_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `logins`
--
ALTER TABLE `logins`
  MODIFY `login_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `settings_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `personal_info_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
